import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/core/lib/auth";
import { prisma } from "@/core/lib/db";
import { isAdmin } from "@/core/lib/permissions";

// GET /api/v1/forms/submissions - Admin only: list all submissions
export async function GET(request: NextRequest) {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!(await isAdmin(session.user.id))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const formId = request.nextUrl.searchParams.get("formId");
    const page = Math.max(1, parseInt(request.nextUrl.searchParams.get("page") || "1") || 1);
    const limit = Math.min(100, Math.max(1, parseInt(request.nextUrl.searchParams.get("limit") || "50") || 50));

    const where: Record<string, unknown> = {};
    if (formId) where.formId = formId;

    const [submissions, total] = await Promise.all([
        prisma.customFormSubmission.findMany({
            where,
            include: {
                form: { select: { id: true, title: true, slug: true } },
            },
            orderBy: { createdAt: "desc" },
            skip: (page - 1) * limit,
            take: limit,
        }),
        prisma.customFormSubmission.count({ where }),
    ]);

    return NextResponse.json({ submissions, total, pages: Math.ceil(total / limit) });
}
