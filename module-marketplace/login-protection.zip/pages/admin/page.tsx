"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function SecuritySettingsPage() {
    const t = useTranslations("loginProtection");
    return (
        <SettingsForm
            title={t("adm_title")}
            subtitle={t("adm_subtitle")}
            saveLabel={t("adm_save")}
            savingLabel={t("adm_saving")}
            savedLabel={t("adm_saved")}
            fields={[
                { key: "enable_email_verification", label: t("adm_field5Label"), placeholder: "false", description: t("adm_field5Desc") },
                { key: "max_login_attempts", label: t("adm_field6Label"), type: "number", placeholder: "10", description: t("adm_field6Desc") },
            ]}
        />
    );
}
