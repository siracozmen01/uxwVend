"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function EmailSettingsPage() {
    const t = useTranslations("emailSystem");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "resend_api_key", label: t("admin.field1Label"), type: "password", placeholder: "re_...", description: t("admin.field1Desc") },
                { key: "email_from", label: t("admin.field2Label"), type: "email", placeholder: "noreply@yoursite.com" },
                { key: "email_from_name", label: t("admin.field3Label"), placeholder: "uxwVend" },
                { key: "email_welcome_subject", label: t("admin.field4Label"), placeholder: "Welcome to {appName}!", description: t("admin.field2Desc") },
                { key: "email_welcome_body", label: t("admin.field5Label"), type: "textarea", description: t("admin.field3Desc") },
                { key: "email_order_subject", label: t("admin.field6Label"), placeholder: "Order #{orderNumber}", description: t("admin.field4Desc") },
                { key: "email_reset_subject", label: t("admin.field7Label"), placeholder: "Reset your password" },
            ]}
        />
    );
}
