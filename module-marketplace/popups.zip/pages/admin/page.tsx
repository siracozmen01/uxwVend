"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("popups");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/popups"
            listKey="popups"
            displayField="title"
            secondaryField="content"
            fields={[
                { key: "title", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "content", label: t("admin.field2Label"), type: "textarea", placeholder: t("admin.field2Placeholder") },
                { key: "image", label: t("admin.field3Label"), type: "url", placeholder: t("admin.field3Placeholder") },
                { key: "link", label: t("admin.field4Label"), type: "url", placeholder: t("admin.field4Placeholder") },
                { key: "linkText", label: t("admin.field5Label"), placeholder: t("admin.field5Placeholder") },
                { key: "isActive", label: t("admin.field6Label"), type: "toggle", defaultValue: "true" },
                { key: "startsAt", label: t("admin.field7Label"), type: "datetime" },
                { key: "endsAt", label: t("admin.field8Label"), type: "datetime" },
            ]}
        />
    );
}
