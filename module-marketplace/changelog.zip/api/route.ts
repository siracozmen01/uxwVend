import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/core/lib/auth";
import { prisma } from "@/core/lib/db";
import { isAdmin } from "@/core/lib/permissions";
import { z } from "zod";

export async function GET() {
    const entries = await prisma.changelogEntry.findMany({
        where: { isActive: true },
        orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ entries });
}

export async function POST(request: NextRequest) {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!(await isAdmin(session.user.id))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const body = await request.json();
    const schema = z.object({
        version: z.string().min(1).max(50),
        title: z.string().min(1).max(200),
        content: z.string().min(1).max(10000),
        type: z.string().max(50).optional(),
    });
    const validation = schema.safeParse(body);
    if (!validation.success) return NextResponse.json({ error: validation.error.issues[0].message }, { status: 400 });

    const { version, title, content, type } = validation.data;

    const entry = await prisma.changelogEntry.create({
        data: { version, title, content, type: type || "update" },
    });
    return NextResponse.json({ entry }, { status: 201 });
}
