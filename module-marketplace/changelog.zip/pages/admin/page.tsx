"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("changelog");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/changelog"
            listKey="entries"
            displayField="title"
            secondaryField="version"
            fields={[
                { key: "version", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "title", label: t("admin.field2Label"), required: true, placeholder: t("admin.field2Placeholder") },
                { key: "content", label: t("admin.field3Label"), type: "textarea", required: true, placeholder: t("admin.field3Placeholder") },
                { key: "type", label: t("admin.field4Label"), placeholder: t("admin.field4Placeholder"), defaultValue: "update" },
            ]}
        />
    );
}
