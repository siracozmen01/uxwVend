"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function AnalyticsSettingsPage() {
    const t = useTranslations("analytics");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "google_analytics_id", label: t("admin.field1Label"), placeholder: "G-XXXXXXXXXX", description: t("admin.field1Desc") },
                { key: "enable_analytics", label: t("admin.field2Label"), placeholder: "true", description: t("admin.field2Desc") },
            ]}
        />
    );
}
