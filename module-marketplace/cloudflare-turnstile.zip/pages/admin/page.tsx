"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/core/components/ui/card";
import { Button } from "@/core/components/ui/button";
import { Input } from "@/core/components/ui/input";
import { Label } from "@/core/components/ui/label";
import { Shield, Loader2, Save } from "lucide-react";
import { toast } from "sonner";

export default function CloudflareTurnstileAdminPage() {
    const t = useTranslations("cloudflareTurnstile");
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [config, setConfig] = useState({ siteKey: "", secretKey: "" });

    useEffect(() => {
        fetch("/api/v1/security/turnstile/settings")
            .then((r) => r.json())
            .then((d) => setConfig({ siteKey: d.siteKey || "", secretKey: d.secretKey || "" }))
            .catch(() => toast.error(t("saveError")))
            .finally(() => setLoading(false));
    }, [t]);

    const save = async () => {
        setSaving(true);
        try {
            const res = await fetch("/api/v1/security/turnstile/settings", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(config),
            });
            if (!res.ok) {
                const data = await res.json().catch(() => ({}));
                toast.error(data.error || t("saveError"));
                return;
            }
            toast.success(t("saved"));
        } catch {
            toast.error(t("saveError"));
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            </div>
        );
    }

    return (
        <div className="max-w-2xl">
            <div className="mb-6">
                <h1 className="text-3xl font-bold flex items-center gap-2">
                    <Shield className="w-7 h-7 text-orange-500" />
                    {t("title")}
                </h1>
                <p className="text-muted-foreground">{t("subtitle")}</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>{t("title")}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label>{t("siteKey")}</Label>
                        <Input
                            value={config.siteKey}
                            onChange={(e) => setConfig({ ...config, siteKey: e.target.value })}
                            placeholder="0x..."
                        />
                    </div>
                    <div>
                        <Label>{t("secretKey")}</Label>
                        <Input
                            type="password"
                            value={config.secretKey}
                            onChange={(e) => setConfig({ ...config, secretKey: e.target.value })}
                            placeholder="0x..."
                        />
                    </div>
                    <Button onClick={save} disabled={saving} className="w-full">
                        {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                        {t("save")}
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}
