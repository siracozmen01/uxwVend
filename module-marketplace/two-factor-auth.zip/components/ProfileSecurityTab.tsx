"use client";

import { useState, useEffect } from "react";
import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/core/components/ui/card";
import { Button } from "@/core/components/ui/button";
import { Input } from "@/core/components/ui/input";
import { Label } from "@/core/components/ui/label";
import { Loader2 } from "lucide-react";

export function ProfileSecurityTab() {
    const t = useTranslations("twoFactorAuth");
    const [twoFAStep, setTwoFAStep] = useState<"idle" | "setup" | "verify" | "backup">("idle");
    const [qrCode, setQrCode] = useState("");
    const [twoFASecret, setTwoFASecret] = useState("");
    const [twoFAToken, setTwoFAToken] = useState("");
    const [backupCodes, setBackupCodes] = useState<string[]>([]);
    const [twoFAError, setTwoFAError] = useState("");
    const [twoFAEnabled, setTwoFAEnabled] = useState(false);
    const [disableToken, setDisableToken] = useState("");
    const [loading, setLoading] = useState(true);

    // Password form
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [savingPassword, setSavingPassword] = useState(false);
    const [passwordSaved, setPasswordSaved] = useState(false);
    const [passwordError, setPasswordError] = useState("");

    useEffect(() => {
        // Check current 2FA status from profile
        fetch("/api/v1/auth/profile")
            .then(r => r.json())
            .then(data => {
                if (data.user) {
                    setTwoFAEnabled(data.user.twoFactorEnabled || false);
                }
            })
            .catch(() => {})
            .finally(() => setLoading(false));
    }, []);

    const changePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        setSavingPassword(true);
        setPasswordError("");
        setPasswordSaved(false);

        if (newPassword !== confirmPassword) {
            setPasswordError(t("invalidCode"));
            setSavingPassword(false);
            return;
        }

        try {
            const res = await fetch("/api/v1/auth/profile", {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
            });
            const data = await res.json();
            if (!res.ok) {
                setPasswordError(data.error || t("setupError"));
                return;
            }
            setPasswordSaved(true);
            setCurrentPassword("");
            setNewPassword("");
            setConfirmPassword("");
            setTimeout(() => setPasswordSaved(false), 3000);
        } catch {
            setPasswordError(t("setupError"));
        } finally {
            setSavingPassword(false);
        }
    };

    if (loading) {
        return (
            <Card>
                <CardContent className="p-8 text-center">
                    <div className="w-6 h-6 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin mx-auto" />
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            {/* 2FA Section */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        {t("title")}
                        <span className={`text-xs px-2 py-1 rounded ${twoFAEnabled ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`}>
                            {twoFAEnabled ? t("enabled") : t("disabled")}
                        </span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {twoFAError && (
                        <div className="p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-lg mb-4">{twoFAError}</div>
                    )}

                    {!twoFAEnabled && twoFAStep === "idle" && (
                        <div>
                            <p className="text-sm text-muted-foreground mb-4">
                                {t("description")}
                            </p>
                            <Button onClick={async () => {
                                setTwoFAError("");
                                const res = await fetch("/api/v1/auth/two-factor/setup", { method: "POST" });
                                const data = await res.json();
                                if (res.ok) {
                                    setQrCode(data.qrCode);
                                    setTwoFASecret(data.secret);
                                    setTwoFAStep("setup");
                                } else {
                                    setTwoFAError(data.error);
                                }
                            }}>
                                {t("enable")}
                            </Button>
                        </div>
                    )}

                    {twoFAStep === "setup" && (
                        <div className="space-y-4 max-w-sm">
                            <p className="text-sm text-muted-foreground">
                                {t("setupDescription")}
                            </p>
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            {qrCode && <img src={qrCode} alt={t("qrCode")} className="mx-auto" />}
                            <div className="text-center">
                                <p className="text-xs text-muted-foreground">{t("manualEntry")}:</p>
                                <code className="text-xs bg-muted px-2 py-1 rounded font-mono select-all">{twoFASecret}</code>
                            </div>
                            <div>
                                <Label>{t("verificationCodePlaceholder")}</Label>
                                <Input
                                    value={twoFAToken}
                                    onChange={(e) => setTwoFAToken(e.target.value)}
                                    placeholder="000000"
                                    className="text-center font-mono text-lg tracking-widest"
                                    maxLength={6}
                                />
                            </div>
                            <Button onClick={async () => {
                                setTwoFAError("");
                                const res = await fetch("/api/v1/auth/two-factor/verify", {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ token: twoFAToken }),
                                });
                                const data = await res.json();
                                if (res.ok) {
                                    setBackupCodes(data.backupCodes);
                                    setTwoFAEnabled(true);
                                    setTwoFAStep("backup");
                                } else {
                                    setTwoFAError(data.error);
                                }
                            }}>
                                {t("verifyAndEnable")}
                            </Button>
                        </div>
                    )}

                    {twoFAStep === "backup" && (
                        <div className="space-y-4">
                            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                <p className="text-sm font-medium text-yellow-800 mb-2">{t("backupCodes")}</p>
                                <p className="text-xs text-yellow-700 mb-3">
                                    {t("backupCodesDescription")}
                                </p>
                                <div className="grid grid-cols-2 gap-2">
                                    {backupCodes.map((code, i) => (
                                        <code key={i} className="text-sm bg-card px-3 py-1 rounded border font-mono text-center">
                                            {code}
                                        </code>
                                    ))}
                                </div>
                            </div>
                            <Button onClick={() => { setTwoFAStep("idle"); setTwoFAToken(""); }}>
                                {t("downloadCodes")}
                            </Button>
                        </div>
                    )}

                    {twoFAEnabled && twoFAStep === "idle" && (
                        <div className="space-y-4 max-w-sm">
                            <p className="text-sm text-muted-foreground">
                                {t("disableWarning")}
                            </p>
                            <Input
                                value={disableToken}
                                onChange={(e) => setDisableToken(e.target.value)}
                                placeholder={t("verificationCodePlaceholder")}
                                className="text-center font-mono"
                                maxLength={6}
                            />
                            <Button variant="destructive" onClick={async () => {
                                setTwoFAError("");
                                const res = await fetch("/api/v1/auth/two-factor/disable", {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ token: disableToken }),
                                });
                                const data = await res.json();
                                if (res.ok) {
                                    setTwoFAEnabled(false);
                                    setDisableToken("");
                                } else {
                                    setTwoFAError(data.error);
                                }
                            }}>
                                {t("disable")}
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Password Section */}
            <Card>
                <CardHeader>
                    <CardTitle>{t("password")}</CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={changePassword} className="space-y-4 max-w-md">
                        {passwordError && (
                            <div className="p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-lg">{passwordError}</div>
                        )}
                        {passwordSaved && (
                            <div className="p-3 bg-green-50 border border-green-100 text-green-600 text-sm rounded-lg">{t("setupSuccess")}</div>
                        )}
                        <div>
                            <Label>{t("enterPassword")}</Label>
                            <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                        </div>
                        <div>
                            <Label>{t("password")}</Label>
                            <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={6} />
                        </div>
                        <div>
                            <Label>{t("verify")}</Label>
                            <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={6} />
                        </div>
                        <Button type="submit" disabled={savingPassword}>
                            {savingPassword ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> </> : t("verify")}
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

export default ProfileSecurityTab;
