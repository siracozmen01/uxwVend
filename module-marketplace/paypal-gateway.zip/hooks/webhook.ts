import { prisma } from "@/core/lib/db";

/**
 * PayPal inbound webhook handler.
 *
 * Signature verification is performed by the core dispatcher at
 * /api/v1/webhook/[provider] using a shared HMAC helper before this
 * handler runs. The real PayPal verification uses their `verify-webhook-
 * signature` REST endpoint with cert/transmission-id headers; hook that
 * in here when production-grade verification is required.
 *
 * TODO: Replace the generic HMAC verification done by core with a real
 * PayPal webhook signature check (see
 * https://developer.paypal.com/api/rest/webhooks/rest/#link-verifywebhooksignature)
 */
export default async function handleWebhook(
    request: Request
): Promise<{ status: number; body?: unknown }> {
    let event: { id?: string; event_type?: string; resource?: unknown } = {};
    try {
        event = await request.json();
    } catch {
        return { status: 400, body: { error: "Invalid JSON" } };
    }

    const eventType = typeof event.event_type === "string" ? event.event_type : "paypal.unknown";

    try {
        await prisma.webhookLog.create({
            data: {
                event: eventType,
                url: request.url,
                status: 200,
                payload: event as object,
            },
        });
    } catch (err) {
        console.error("[paypal-gateway] failed to log webhook:", err);
    }

    // TODO: Dispatch PAYMENT.CAPTURE.COMPLETED, BILLING.SUBSCRIPTION.*
    // etc. into the store module to update orders/subscriptions.

    return { status: 200, body: { received: true, event: eventType } };
}
