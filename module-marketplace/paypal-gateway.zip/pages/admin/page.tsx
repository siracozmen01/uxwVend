"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function PayPalSettingsPage() {
    const t = useTranslations("paypalGateway");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "paypal_client_id", label: t("admin.field1Label"), placeholder: "AW...", description: t("admin.field1Desc") },
                { key: "paypal_client_secret", label: t("admin.field2Label"), type: "password", placeholder: "EL...", description: t("admin.field2Desc") },
                { key: "paypal_mode", label: t("admin.field3Label"), placeholder: "sandbox", description: t("admin.field3Desc") },
            ]}
        />
    );
}
