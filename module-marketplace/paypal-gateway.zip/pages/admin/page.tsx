"use client";
import { SettingsForm } from "./settings-form";

export default function PayPalSettingsPage() {
    return (
        <SettingsForm
            title="PayPal Configuration"
            subtitle="Configure PayPal payment gateway"
            fields={[
                { key: "paypal_client_id", label: "Client ID", placeholder: "AW...", description: "PayPal app Client ID" },
                { key: "paypal_client_secret", label: "Client Secret", type: "password", placeholder: "EL...", description: "PayPal app Secret (keep this private)" },
                { key: "paypal_mode", label: "Mode", placeholder: "sandbox", description: "Set to 'live' for production, 'sandbox' for testing" },
            ]}
        />
    );
}
