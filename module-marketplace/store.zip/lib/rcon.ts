import { prisma } from "@/core/lib/db";

interface RconConfig {
    host: string;
    port: number;
    password: string;
}

async function getRconConfig(): Promise<RconConfig | null> {
    if (process.env.RCON_HOST && process.env.RCON_PASSWORD) {
        return {
            host: process.env.RCON_HOST,
            port: parseInt(process.env.RCON_PORT || "25575"),
            password: process.env.RCON_PASSWORD,
        };
    }
    try {
        const settings = await prisma.setting.findMany({
            where: { key: { startsWith: "rcon_" } },
        });
        const map: Record<string, string> = {};
        settings.forEach((s: { key: string; value: unknown }) => { map[s.key] = s.value as string; });
        if (map.rcon_host && map.rcon_password) {
            return {
                host: map.rcon_host,
                port: parseInt(map.rcon_port || "25575"),
                password: map.rcon_password,
            };
        }
    } catch { /* ignore */ }
    return null;
}

export function getRconEnabled(): boolean {
    return !!(process.env.RCON_HOST && process.env.RCON_PASSWORD);
}

export async function sendRconCommand(command: string): Promise<string> {
    const config = await getRconConfig();
    if (!config) throw new Error("RCON not configured");
    try {
        const { Rcon } = await import("rcon-client") as { Rcon: { connect: (cfg: RconConfig) => Promise<{ send: (cmd: string) => Promise<string>; end: () => void }> } };
        const rcon = await Rcon.connect(config);
        try {
            return await rcon.send(command);
        } finally {
            rcon.end();
        }
    } catch (err) {
        throw new Error(`RCON failed: ${err instanceof Error ? err.message : "Unknown error"}`);
    }
}

function sanitizeRconArg(input: string): string {
    return input.replace(/[^a-zA-Z0-9_\-. ]/g, '');
}

export async function deliverProduct(params: {
    playerName: string;
    productName: string;
    commands: string[];
    quantity?: number;
    variables?: Record<string, string>;
}): Promise<{ success: boolean; results: string[] }> {
    const results: string[] = [];
    const safePlayerName = sanitizeRconArg(params.playerName);
    const safeProductName = sanitizeRconArg(params.productName);
    for (const cmd of params.commands) {
        let command = cmd
            .replace(/\{player\}/g, safePlayerName)
            .replace(/\{product\}/g, safeProductName)
            .replace(/\{quantity\}/g, String(params.quantity || 1));

        // Replace custom variable placeholders: {variableName}
        if (params.variables) {
            for (const [key, value] of Object.entries(params.variables)) {
                command = command.replace(new RegExp(`\\{${key}\\}`, "g"), sanitizeRconArg(value));
            }
        }
        try {
            const result = await sendRconCommand(command);
            results.push(result);
        } catch (err) {
            results.push(`Error: ${err instanceof Error ? err.message : "Unknown"}`);
            return { success: false, results };
        }
    }
    return { success: true, results };
}
