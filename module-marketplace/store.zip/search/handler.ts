import { prisma } from "@/core/lib/db";

interface SearchResult {
    type: string;
    title: string;
    excerpt?: string;
    href: string;
    image?: string;
}

/**
 * Federated search contribution for store products.
 * Called from /api/v1/search?q=... via the ModuleSearchProviders registry.
 */
export default async function search(q: string): Promise<SearchResult[]> {
    if (!q || q.length < 2) return [];
    const rows = await prisma.product.findMany({
        where: {
            AND: [
                { isActive: true },
                {
                    OR: [
                        { name: { contains: q, mode: "insensitive" } },
                        { shortDesc: { contains: q, mode: "insensitive" } },
                        { description: { contains: q, mode: "insensitive" } },
                    ],
                },
            ],
        },
        select: { name: true, slug: true, shortDesc: true, image: true },
        orderBy: { createdAt: "desc" },
        take: 5,
    });
    return rows.map((r) => ({
        type: "product",
        title: r.name,
        excerpt: r.shortDesc ?? undefined,
        href: `/store/${r.slug}`,
        image: r.image ?? undefined,
    }));
}
