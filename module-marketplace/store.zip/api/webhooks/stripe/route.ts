import { NextRequest, NextResponse } from "next/server";
import { stripe } from "../../../lib/stripe";
import { prisma } from "@/core/lib/db";
import { sendOrderConfirmationEmail } from "../../../lib/email";
import { sendDiscordWebhook } from "@/core/lib/discord";
import { deliverProduct } from "../../../lib/rcon";
import Stripe from "stripe";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
    const body = await request.text();
    const signature = request.headers.get("stripe-signature");

    if (!signature) {
        return NextResponse.json({ error: "Missing signature" }, { status: 400 });
    }

    let event: Stripe.Event;
    try {
        event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET || "");
    } catch (err) {
        console.error("Webhook signature verification failed:", err);
        return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
    }

    switch (event.type) {
        case "checkout.session.completed": {
            const session = event.data.object as Stripe.Checkout.Session;
            const orderId = session.metadata?.orderId;
            if (!orderId) break;

            // Idempotency check
            const existingOrder = await prisma.order.findUnique({ where: { id: orderId } });
            if (!existingOrder || existingOrder.status === "COMPLETED") {
                return NextResponse.json({ received: true });
            }

            // Update order status
            await prisma.order.update({
                where: { id: orderId },
                data: { status: "COMPLETED", paymentMethod: "stripe", paymentId: session.payment_intent as string },
            });

            // Fetch full order with items
            const order = await prisma.order.findUnique({
                where: { id: orderId },
                include: {
                    user: { select: { email: true, username: true } },
                    items: true,
                },
            });
            if (!order) break;

            // ── Grant ownership (moved from checkout — only after payment confirmed) ──
            for (const item of order.items) {
                if (!item.productId) continue;
                await prisma.chestItem.create({
                    data: {
                        userId: order.userId,
                        productId: item.productId,
                        productName: item.name,
                        quantity: item.quantity,
                        orderId: order.id,
                    },
                });
                await prisma.ownedProduct.upsert({
                    where: { userId_productId: { userId: order.userId, productId: item.productId } },
                    update: {},
                    create: { userId: order.userId, productId: item.productId, orderId: order.id },
                });
            }

            // ── Send confirmation email ──
            sendOrderConfirmationEmail(order.user.email, order.orderNumber, Number(order.total)).catch(console.error);

            // ── Discord notification ──
            sendDiscordWebhook("order_completed", {
                embeds: [{
                    title: "Order Completed",
                    color: 0x22c55e,
                    fields: [
                        { name: "Order", value: order.orderNumber, inline: true },
                        { name: "Total", value: `${Number(order.total)} ${order.currency}`, inline: true },
                        { name: "User", value: order.user.username || order.user.email, inline: true },
                    ],
                    timestamp: new Date().toISOString(),
                }],
            }).catch(console.error);

            // ── RCON delivery ──
            const playerName = session.metadata?.playerName
                || (order.metadata as Record<string, unknown>)?.playerName as string
                || order.user.username
                || "Player";

            for (const item of order.items) {
                if (!item.productId) continue;
                const commands = await prisma.productCommand.findMany({
                    where: { productId: item.productId },
                    orderBy: { order: "asc" },
                });
                if (commands.length === 0) continue;

                // Extract per-item variables from metadata
                const itemVars = (item.metadata as Record<string, unknown>)?.variables as Record<string, string> | undefined;

                deliverProduct({
                    playerName,
                    productName: item.name,
                    commands: commands.map((c) => c.command),
                    quantity: item.quantity,
                    variables: itemVars,
                }).catch(console.error);
            }

            // ── Payment record ──
            await prisma.payment.create({
                data: {
                    orderId,
                    provider: "stripe",
                    providerId: session.payment_intent as string,
                    amount: (session.amount_total || 0) / 100,
                    currency: session.currency || "usd",
                    status: "COMPLETED",
                    metadata: { checkoutSessionId: session.id, customerEmail: session.customer_details?.email },
                },
            });
            break;
        }

        case "checkout.session.expired": {
            const session = event.data.object as Stripe.Checkout.Session;
            const orderId = session.metadata?.orderId;
            if (orderId) {
                await prisma.order.update({ where: { id: orderId }, data: { status: "CANCELLED" } });
            }
            break;
        }

        case "charge.refunded": {
            const charge = event.data.object as Stripe.Charge;
            const paymentIntentId = charge.payment_intent as string;
            if (paymentIntentId) {
                const payment = await prisma.payment.findFirst({ where: { providerId: paymentIntentId } });
                if (payment) {
                    await prisma.order.update({ where: { id: payment.orderId }, data: { status: "REFUNDED" } });
                    await prisma.payment.update({ where: { id: payment.id }, data: { status: "REFUNDED" } });
                }
            }
            break;
        }
    }

    return NextResponse.json({ received: true });
}
