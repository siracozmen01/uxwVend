import { NextResponse } from "next/server";
import { prisma } from "@/core/lib/db";
import { formatCurrency } from "@/core/lib/utils";

export async function GET() {
    const [products, orders, revenueData] = await Promise.all([
        prisma.product.count(),
        prisma.order.count(),
        prisma.order.aggregate({ _sum: { total: true }, where: { status: "COMPLETED" } }),
    ]);
    const revenue = Number(revenueData._sum.total || 0);
    
    const recentOrders = await prisma.order.findMany({
        take: 5, orderBy: { createdAt: "desc" },
        include: { user: { select: { username: true } } },
    });

    return NextResponse.json({
        stats: { products, orders, revenue },
        sections: [{
            id: "recent-orders",
            title: "Recent Orders",
            titleKey: "dashboard_recentOrders",
            viewAllHref: "/admin/store/orders",
            items: recentOrders.map(o => ({
                id: o.id,
                href: "/admin/store/orders/" + o.id,
                primary: o.orderNumber,
                secondary: o.user.username + " · " + o.createdAt.toISOString().split("T")[0],
                badge: o.status,
                badgeColor: o.status === "COMPLETED" ? "green" : o.status === "PENDING" ? "yellow" : "blue",
                value: formatCurrency(Number(o.total)),
            }))
        }]
    });
}
