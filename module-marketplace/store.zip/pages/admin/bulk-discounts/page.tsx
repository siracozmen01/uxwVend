"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("store");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/bulk-discounts"
            listKey="discounts"
            displayField="name"
            secondaryField="minQuantity"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "minQuantity", label: t("admin.field2Label"), type: "number", required: true, placeholder: t("admin.field2Placeholder") },
                { key: "discountPercent", label: t("admin.field3Label"), type: "number", required: true, placeholder: t("admin.field3Placeholder") },
                { key: "productId", label: t("admin.field4Label"), placeholder: t("admin.field4Placeholder") },
                { key: "categoryId", label: t("admin.field5Label"), placeholder: t("admin.field5Placeholder") },
                { key: "isActive", label: t("admin.field6Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
