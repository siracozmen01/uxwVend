"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("store");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/creator-codes"
            listKey="codes"
            displayField="code"
            secondaryField="creatorId"
            fields={[
                { key: "code", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "creatorId", label: t("admin.field2Label"), required: true, placeholder: t("admin.field2Placeholder") },
                { key: "discountPercent", label: t("admin.field3Label"), type: "number", placeholder: t("admin.field3Placeholder"), defaultValue: "5" },
                { key: "commissionPercent", label: t("admin.field4Label"), type: "number", placeholder: t("admin.field4Placeholder"), defaultValue: "5" },
                { key: "isActive", label: t("admin.field5Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
