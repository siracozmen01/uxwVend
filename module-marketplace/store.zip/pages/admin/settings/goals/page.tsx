"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function GoalsSettingsPage() {
    const t = useTranslations("store");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "community_goal_title", label: t("admin.field1Label"), placeholder: "Monthly Goal", description: t("admin.field1Desc") },
                { key: "community_goal_target", label: t("admin.field2Label"), type: "number", placeholder: "5000", description: t("admin.field2Desc") },
                { key: "community_goal_end_date", label: t("admin.field3Label"), placeholder: "2026-12-31", description: t("admin.field3Desc") },
            ]}
        />
    );
}
