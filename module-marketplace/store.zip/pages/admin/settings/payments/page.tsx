"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function PaymentSettingsPage() {
    const t = useTranslations("store");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "stripe_public_key", label: t("admin.field1Label"), placeholder: "pk_...", description: t("admin.field1Desc") },
                { key: "stripe_secret_key", label: t("admin.field2Label"), type: "password", placeholder: "sk_...", description: t("admin.field2Desc") },
                { key: "stripe_webhook_secret", label: t("admin.field3Label"), type: "password", placeholder: "whsec_...", description: t("admin.field3Desc") },
                { key: "default_currency", label: t("admin.field4Label"), placeholder: "usd", description: t("admin.field4Desc") },
                { key: "tax_rate", label: t("admin.field5Label"), type: "number", placeholder: "0", description: t("admin.field5Desc") },
            ]}
        />
    );
}
