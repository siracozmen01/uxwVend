import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/core/lib/auth";
import { prisma } from "@/core/lib/db";
import { rateLimit } from "@/core/lib/rate-limit";
import { z } from "zod";

// GET /api/v1/suggestions - Public list
export async function GET(request: NextRequest) {
    const status = request.nextUrl.searchParams.get("status");
    const sort = request.nextUrl.searchParams.get("sort") || "newest";
    const page = Math.max(1, parseInt(request.nextUrl.searchParams.get("page") || "1") || 1);
    const limit = Math.min(100, Math.max(1, parseInt(request.nextUrl.searchParams.get("limit") || "20") || 20));

    const where = status ? { status } : {};
    const orderBy = sort === "popular"
        ? { upvotes: "desc" as const }
        : { createdAt: "desc" as const };

    const [suggestions, total] = await Promise.all([
        prisma.suggestion.findMany({
            where,
            include: {
                author: { select: { id: true, username: true, avatar: true } },
                _count: { select: { votes: true } },
            },
            orderBy,
            skip: (page - 1) * limit,
            take: limit,
        }),
        prisma.suggestion.count({ where }),
    ]);

    return NextResponse.json({ suggestions, total, pages: Math.ceil(total / limit) });
}

// POST /api/v1/suggestions - Create suggestion
export async function POST(request: NextRequest) {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const ip = request.headers.get("x-forwarded-for") || "unknown";
    const rl = rateLimit(`suggestion:${session.user.id || ip}`, { maxRequests: 5, windowMs: 86400000 });
    if (!rl.success) {
        return NextResponse.json({ error: "Too many requests. Try again later." }, { status: 429 });
    }

    const body = await request.json();
    const schema = z.object({
        title: z.string().min(3).max(200),
        content: z.string().min(10).max(5000),
    });
    const validation = schema.safeParse(body);
    if (!validation.success) return NextResponse.json({ error: validation.error.issues[0].message }, { status: 400 });

    const { title, content } = validation.data;

    const suggestion = await prisma.suggestion.create({
        data: {
            title,
            content,
            authorId: session.user.id,
        },
        include: {
            author: { select: { id: true, username: true, avatar: true } },
        },
    });

    return NextResponse.json({ suggestion }, { status: 201 });
}
