"use client";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    return (
        <AdminCrudPage
            title="Ticket Departments"
            subtitle="Manage support ticket departments"
            apiPath="/api/v1/tickets/departments"
            listKey="departments"
            displayField="name"
            secondaryField="description"
            fields={[
                { key: "name", label: "Name", required: true, placeholder: "e.g. Billing, Technical Support" },
                { key: "description", label: "Description", placeholder: "Brief description of this department" },
                { key: "color", label: "Color", type: "color", defaultValue: "#3b82f6" },
                { key: "order", label: "Sort Order", type: "number", placeholder: "0", defaultValue: "0" },
                { key: "isActive", label: "Active", type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
