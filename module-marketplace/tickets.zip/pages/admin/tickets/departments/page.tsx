"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("tickets");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/tickets/departments"
            listKey="departments"
            displayField="name"
            secondaryField="description"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "description", label: t("admin.field2Label"), placeholder: t("admin.field2Placeholder") },
                { key: "color", label: t("admin.field3Label"), type: "color", defaultValue: "#3b82f6" },
                { key: "order", label: t("admin.field4Label"), type: "number", placeholder: t("admin.field3Placeholder"), defaultValue: "0" },
                { key: "isActive", label: t("admin.field5Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
