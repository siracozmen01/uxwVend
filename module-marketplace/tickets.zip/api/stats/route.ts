import { NextResponse } from "next/server";
import { prisma } from "@/core/lib/db";

export async function GET() {
    const tickets = await prisma.ticket.count();
    const openTickets = await prisma.ticket.findMany({
        take: 5,
        where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING_REPLY"] } },
        orderBy: { createdAt: "desc" },
        include: { user: { select: { username: true } }, department: { select: { name: true } } },
    });

    return NextResponse.json({
        stats: { tickets },
        sections: [{
            id: "open-tickets",
            title: "Open Tickets",
            titleKey: "dashboard_openTickets",
            viewAllHref: "/admin/tickets",
            items: openTickets.map(t => ({
                id: t.id,
                href: "/admin/tickets/" + t.id,
                primary: t.subject,
                secondary: t.user.username + " · " + (t.department?.name || ""),
                badge: t.status,
                badgeColor: "blue",
            }))
        }]
    });
}
