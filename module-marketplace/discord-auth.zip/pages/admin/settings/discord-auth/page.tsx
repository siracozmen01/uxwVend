"use client";
import { SettingsForm } from "./settings-form";

export default function DiscordAuthSettingsPage() {
    return (
        <SettingsForm
            title="Discord OAuth"
            subtitle="Configure Discord login for your users"
            fields={[
                { key: "discord_client_id", label: "Discord Client ID", placeholder: "123456789012345678", description: "From discord.com/developers/applications" },
                { key: "discord_client_secret", label: "Discord Client Secret", type: "password", placeholder: "Your client secret", description: "Keep this secret. Found under OAuth2 in your Discord app." },
                { key: "discord_redirect_uri", label: "Redirect URI", type: "url", placeholder: "https://yoursite.com/api/auth/callback/discord", description: "Must match the redirect URI in your Discord application" },
            ]}
        />
    );
}
