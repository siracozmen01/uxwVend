"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function DiscordAuthSettingsPage() {
    const t = useTranslations("discord-auth");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "discord_client_id", label: t("admin.field1Label"), placeholder: "123456789012345678", description: t("admin.field1Desc") },
                { key: "discord_client_secret", label: t("admin.field2Label"), type: "password", placeholder: "Your client secret", description: t("admin.field2Desc") },
                { key: "discord_redirect_uri", label: t("admin.field3Label"), type: "url", placeholder: "https://yoursite.com/api/auth/callback/discord", description: t("admin.field3Desc") },
            ]}
        />
    );
}
