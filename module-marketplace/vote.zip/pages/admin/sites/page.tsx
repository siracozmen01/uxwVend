"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("vote");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/vote"
            listKey="sites"
            displayField="name"
            secondaryField="url"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "url", label: t("admin.field2Label"), type: "url", required: true, placeholder: t("admin.field2Placeholder") },
                { key: "reward", label: t("admin.field3Label"), type: "number", placeholder: t("admin.field3Placeholder"), defaultValue: "10" },
                { key: "icon", label: t("admin.field4Label"), placeholder: t("admin.field4Placeholder") },
                { key: "isActive", label: t("admin.field5Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
