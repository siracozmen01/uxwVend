"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function StripeSettingsPage() {
    const t = useTranslations("stripeGateway");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "stripe_public_key", label: t("admin.field1Label"), placeholder: "pk_...", description: t("admin.field1Desc") },
                { key: "stripe_secret_key", label: t("admin.field2Label"), type: "password", placeholder: "sk_...", description: t("admin.field2Desc") },
                { key: "stripe_webhook_secret", label: t("admin.field3Label"), type: "password", placeholder: "whsec_...", description: t("admin.field3Desc") },
            ]}
        />
    );
}
