-- Blog module: initial schema
-- Creates BlogCategory, BlogArticle, BlogComment, BlogTag + join table
-- The ArticleStatus enum must exist before this runs (declared in the merged
-- schema.prisma, created by the initial core push).

CREATE TABLE IF NOT EXISTS public."BlogCategory" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT "BlogCategory_pkey" PRIMARY KEY (id)
);

CREATE UNIQUE INDEX IF NOT EXISTS "BlogCategory_slug_key" ON public."BlogCategory" USING btree (slug);
CREATE INDEX IF NOT EXISTS "BlogCategory_slug_idx" ON public."BlogCategory" USING btree (slug);

DO $$ BEGIN
    CREATE TYPE public."ArticleStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'SCHEDULED', 'ARCHIVED');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

CREATE SEQUENCE IF NOT EXISTS public."BlogArticle_number_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE IF NOT EXISTS public."BlogArticle" (
    id text NOT NULL,
    number integer DEFAULT nextval('public."BlogArticle_number_seq"'::regclass) NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text NOT NULL,
    "coverImage" text,
    status public."ArticleStatus" DEFAULT 'DRAFT'::public."ArticleStatus" NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    views integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "categoryId" text,
    "authorId" text NOT NULL,
    CONSTRAINT "BlogArticle_pkey" PRIMARY KEY (id),
    CONSTRAINT "BlogArticle_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT "BlogArticle_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."BlogCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL
);

ALTER SEQUENCE public."BlogArticle_number_seq" OWNED BY public."BlogArticle".number;

CREATE UNIQUE INDEX IF NOT EXISTS "BlogArticle_slug_key" ON public."BlogArticle" USING btree (slug);
CREATE UNIQUE INDEX IF NOT EXISTS "BlogArticle_number_key" ON public."BlogArticle" USING btree (number);
CREATE INDEX IF NOT EXISTS "BlogArticle_slug_idx" ON public."BlogArticle" USING btree (slug);
CREATE INDEX IF NOT EXISTS "BlogArticle_status_idx" ON public."BlogArticle" USING btree (status);
CREATE INDEX IF NOT EXISTS "BlogArticle_authorId_idx" ON public."BlogArticle" USING btree ("authorId");

CREATE TABLE IF NOT EXISTS public."BlogComment" (
    id text NOT NULL,
    content text NOT NULL,
    "isApproved" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "articleId" text NOT NULL,
    "authorId" text NOT NULL,
    CONSTRAINT "BlogComment_pkey" PRIMARY KEY (id),
    CONSTRAINT "BlogComment_articleId_fkey" FOREIGN KEY ("articleId") REFERENCES public."BlogArticle"(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT "BlogComment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS "BlogComment_articleId_idx" ON public."BlogComment" USING btree ("articleId");
CREATE INDEX IF NOT EXISTS "BlogComment_authorId_idx" ON public."BlogComment" USING btree ("authorId");

CREATE TABLE IF NOT EXISTS public."BlogTag" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    CONSTRAINT "BlogTag_pkey" PRIMARY KEY (id)
);

CREATE UNIQUE INDEX IF NOT EXISTS "BlogTag_name_key" ON public."BlogTag" USING btree (name);
CREATE UNIQUE INDEX IF NOT EXISTS "BlogTag_slug_key" ON public."BlogTag" USING btree (slug);
CREATE INDEX IF NOT EXISTS "BlogTag_slug_idx" ON public."BlogTag" USING btree (slug);

CREATE TABLE IF NOT EXISTS public."_BlogArticleToBlogTag" (
    "A" text NOT NULL,
    "B" text NOT NULL,
    CONSTRAINT "_BlogArticleToBlogTag_AB_pkey" PRIMARY KEY ("A", "B"),
    CONSTRAINT "_BlogArticleToBlogTag_A_fkey" FOREIGN KEY ("A") REFERENCES public."BlogArticle"(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT "_BlogArticleToBlogTag_B_fkey" FOREIGN KEY ("B") REFERENCES public."BlogTag"(id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "_BlogArticleToBlogTag_B_index" ON public."_BlogArticleToBlogTag" USING btree ("B");
