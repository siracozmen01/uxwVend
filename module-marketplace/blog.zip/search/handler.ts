import { prisma } from "@/core/lib/db";

interface SearchResult {
    type: string;
    title: string;
    excerpt?: string;
    href: string;
}

/**
 * Federated search contribution for blog articles.
 * Called from /api/v1/search?q=... via the ModuleSearchProviders registry.
 */
export default async function search(q: string): Promise<SearchResult[]> {
    if (!q || q.length < 2) return [];
    const rows = await prisma.blogArticle.findMany({
        where: {
            AND: [
                { status: "PUBLISHED" },
                {
                    OR: [
                        { title: { contains: q, mode: "insensitive" } },
                        { excerpt: { contains: q, mode: "insensitive" } },
                        { content: { contains: q, mode: "insensitive" } },
                    ],
                },
            ],
        },
        select: { title: true, slug: true, excerpt: true },
        orderBy: { createdAt: "desc" },
        take: 5,
    });
    return rows.map((r) => ({
        type: "blog-article",
        title: r.title,
        excerpt: r.excerpt ?? undefined,
        href: `/blog/${r.slug}`,
    }));
}
