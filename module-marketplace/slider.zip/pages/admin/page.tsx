"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("slider");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/slider"
            listKey="items"
            displayField="title"
            secondaryField="image"
            fields={[
                { key: "title", label: t("admin.field1Label"), placeholder: t("admin.field1Placeholder") },
                { key: "subtitle", label: t("admin.field2Label"), placeholder: t("admin.field2Placeholder") },
                { key: "image", label: t("admin.field3Label"), type: "url", required: true, placeholder: t("admin.field3Placeholder") },
                { key: "link", label: t("admin.field4Label"), type: "url", placeholder: t("admin.field4Placeholder") },
                { key: "order", label: t("admin.field5Label"), type: "number", defaultValue: "0" },
                { key: "isActive", label: t("admin.field6Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
