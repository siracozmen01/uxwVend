import { prisma } from "@/core/lib/db";

interface SearchResult {
    type: string;
    title: string;
    excerpt?: string;
    href: string;
}

/**
 * Federated search contribution for help-center articles.
 * Called from /api/v1/search?q=... via the ModuleSearchProviders registry.
 */
export default async function search(q: string): Promise<SearchResult[]> {
    if (!q || q.length < 2) return [];
    const rows = await prisma.helpArticle.findMany({
        where: {
            OR: [
                { title: { contains: q, mode: "insensitive" } },
                { content: { contains: q, mode: "insensitive" } },
            ],
        },
        select: { title: true, slug: true, content: true },
        orderBy: { createdAt: "desc" },
        take: 5,
    });
    return rows.map((r) => ({
        type: "help-article",
        title: r.title,
        excerpt: r.content.slice(0, 140),
        href: `/help/${r.slug}`,
    }));
}
