"use client";
import { SettingsForm } from "./settings-form";

export default function GoogleAuthSettingsPage() {
    return (
        <SettingsForm
            title="Google OAuth"
            subtitle="Configure Google login for your users"
            fields={[
                { key: "google_client_id", label: "Google Client ID", placeholder: "xxxx.apps.googleusercontent.com", description: "From console.cloud.google.com under APIs & Services > Credentials" },
                { key: "google_client_secret", label: "Google Client Secret", type: "password", placeholder: "Your client secret", description: "Keep this secret. Found in your Google Cloud OAuth client." },
                { key: "google_redirect_uri", label: "Redirect URI", type: "url", placeholder: "https://yoursite.com/api/auth/callback/google", description: "Must match the authorized redirect URI in Google Cloud Console" },
            ]}
        />
    );
}
