"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function GoogleAuthSettingsPage() {
    const t = useTranslations("googleAuth");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "google_client_id", label: t("admin.field1Label"), placeholder: "xxxx.apps.googleusercontent.com", description: t("admin.field1Desc") },
                { key: "google_client_secret", label: t("admin.field2Label"), type: "password", placeholder: "Your client secret", description: t("admin.field2Desc") },
                { key: "google_redirect_uri", label: t("admin.field3Label"), type: "url", placeholder: "https://yoursite.com/api/auth/callback/google", description: t("admin.field3Desc") },
            ]}
        />
    );
}
