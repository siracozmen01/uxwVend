"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function ResendSettingsPage() {
    const t = useTranslations("resendProvider");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "resend_api_key", label: t("admin.field1Label"), type: "password", placeholder: "re_...", description: t("admin.field1Desc") },
                { key: "email_from", label: t("admin.field2Label"), type: "email", placeholder: "noreply@yoursite.com", description: t("admin.field2Desc") },
                { key: "email_from_name", label: t("admin.field3Label"), placeholder: "uxwVend", description: t("admin.field3Desc") },
            ]}
        />
    );
}
