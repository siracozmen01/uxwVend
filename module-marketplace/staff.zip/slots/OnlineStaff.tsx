"use client";

import { useEffect, useState } from "react";
import { Users } from "lucide-react";

interface Member {
    id: string;
    username: string;
    avatar: string | null;
}

/**
 * Slot contribution rendered below the hero banner.
 * Shows a small strip of currently-online staff with avatars.
 * Fetches from /api/v1/users?online=1&staff=1 — endpoint may not
 * exist yet, in which case the component simply renders nothing.
 */
export default function OnlineStaff() {
    const [members, setMembers] = useState<Member[]>([]);
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        let active = true;
        fetch("/api/v1/users?online=1&staff=1&limit=8")
            .then((r) => (r.ok ? r.json() : { users: [] }))
            .then((d: { users?: Member[] }) => {
                if (!active) return;
                setMembers(d.users || []);
                setLoaded(true);
            })
            .catch(() => { if (active) setLoaded(true); });
        return () => { active = false; };
    }, []);

    if (!loaded || members.length === 0) return null;

    return (
        <div className="container mx-auto px-4 -mt-6 mb-4">
            <div className="bg-card border border-border rounded-lg px-4 py-2 flex items-center gap-3 shadow-sm">
                <Users className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    {members.length} staff online
                </span>
                <div className="flex -space-x-2 ml-auto">
                    {members.slice(0, 5).map((m) => (
                        <div
                            key={m.id}
                            className="w-7 h-7 rounded-full border-2 border-background overflow-hidden bg-muted flex items-center justify-center text-xs font-semibold"
                            title={m.username}
                        >
                            {m.avatar ? (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img src={m.avatar} alt={m.username} className="w-full h-full object-cover" />
                            ) : (
                                m.username.slice(0, 1).toUpperCase()
                            )}
                        </div>
                    ))}
                    {members.length > 5 && (
                        <div className="w-7 h-7 rounded-full border-2 border-background bg-muted flex items-center justify-center text-[10px] font-semibold text-muted-foreground">
                            +{members.length - 5}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
