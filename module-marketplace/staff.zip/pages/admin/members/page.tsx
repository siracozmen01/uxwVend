"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("staff");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/staff"
            listKey="members"
            displayField="name"
            secondaryField="role"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "role", label: t("admin.field2Label"), required: true, placeholder: t("admin.field2Placeholder") },
                { key: "avatar", label: t("admin.field3Label"), type: "url", placeholder: t("admin.field3Placeholder") },
                { key: "order", label: t("admin.field4Label"), type: "number", placeholder: t("admin.field4Placeholder") },
                { key: "isActive", label: t("admin.field5Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
