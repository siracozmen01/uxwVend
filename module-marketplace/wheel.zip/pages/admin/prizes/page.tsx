"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("wheel");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/wheel/prizes"
            listKey="prizes"
            displayField="name"
            secondaryField="type"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "type", label: t("admin.field2Label"), type: "select", required: true, options: [
                    { value: "credits", label: t("admin.field3Label") },
                    { value: "coupon", label: t("admin.field4Label") },
                    { value: "nothing", label: t("admin.field5Label") },
                ], defaultValue: "credits" },
                { key: "value", label: t("admin.field6Label"), type: "number", placeholder: t("admin.field2Placeholder"), defaultValue: "0" },
                { key: "color", label: t("admin.field7Label"), type: "color", defaultValue: "#3b82f6" },
                { key: "probability", label: t("admin.field8Label"), type: "number", placeholder: t("admin.field3Placeholder"), defaultValue: "10" },
                { key: "isActive", label: t("admin.field9Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
