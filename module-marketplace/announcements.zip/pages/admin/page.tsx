"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("announcements");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/announcements"
            listKey="announcements"
            displayField="title"
            secondaryField="type"
            fields={[
                { key: "title", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "content", label: t("admin.field2Label"), type: "textarea", required: true, placeholder: t("admin.field2Placeholder") },
                { key: "type", label: t("admin.field3Label"), type: "select", options: [
                    { value: "info", label: t("admin.field4Label") },
                    { value: "warning", label: t("admin.field5Label") },
                    { value: "success", label: t("admin.field6Label") },
                    { value: "error", label: t("admin.field7Label") },
                ], defaultValue: "info" },
                { key: "isActive", label: t("admin.field8Label"), type: "toggle", defaultValue: "true" },
                { key: "dismissible", label: t("admin.field9Label"), type: "toggle", defaultValue: "true" },
                { key: "includePages", label: t("admin.field10Label"), placeholder: t("admin.field3Placeholder") },
                { key: "excludePages", label: t("admin.field11Label"), placeholder: t("admin.field4Placeholder") },
                { key: "startsAt", label: t("admin.field12Label"), type: "datetime" },
                { key: "endsAt", label: t("admin.field13Label"), type: "datetime" },
            ]}
        />
    );
}
