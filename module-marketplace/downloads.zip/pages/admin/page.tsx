"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("downloads");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/downloads"
            listKey="downloads"
            displayField="title"
            secondaryField="fileName"
            fields={[
                { key: "title", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "description", label: t("admin.field2Label"), type: "textarea", placeholder: t("admin.field2Placeholder") },
                { key: "fileName", label: t("admin.field3Label"), required: true, placeholder: t("admin.field3Placeholder") },
                { key: "fileUrl", label: t("admin.field4Label"), type: "url", required: true, placeholder: t("admin.field4Placeholder") },
                { key: "fileSize", label: t("admin.field5Label"), type: "number", placeholder: t("admin.field5Placeholder") },
                { key: "isActive", label: t("admin.field6Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
