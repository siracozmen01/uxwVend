"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function SecuritySettingsPage() {
    const t = useTranslations("security");
    return (
        <SettingsForm
            title={t("adm_title")}
            subtitle={t("adm_subtitle")}
            fields={[
                { key: "turnstile_site_key", label: t("adm_field1Label"), placeholder: "0x...", description: t("adm_field1Desc") },
                { key: "turnstile_secret_key", label: t("adm_field2Label"), type: "password", placeholder: "0x...", description: t("adm_field2Desc") },
                { key: "enable_captcha_login", label: t("adm_field3Label"), placeholder: "true", description: t("adm_field3Desc") },
                { key: "enable_captcha_register", label: t("adm_field4Label"), placeholder: "true", description: t("adm_field4Desc") },
                { key: "enable_email_verification", label: t("adm_field5Label"), placeholder: "false", description: t("adm_field5Desc") },
                { key: "max_login_attempts", label: t("adm_field6Label"), type: "number", placeholder: "10", description: t("adm_field6Desc") },
            ]}
        />
    );
}
