"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function SecuritySettingsPage() {
    const t = useTranslations("security");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "turnstile_site_key", label: t("admin.field1Label"), placeholder: "0x...", description: t("admin.field1Desc") },
                { key: "turnstile_secret_key", label: t("admin.field2Label"), type: "password", placeholder: "0x...", description: t("admin.field2Desc") },
                { key: "enable_captcha_login", label: t("admin.field3Label"), placeholder: "true", description: t("admin.field3Desc") },
                { key: "enable_captcha_register", label: t("admin.field4Label"), placeholder: "true", description: t("admin.field4Desc") },
                { key: "enable_email_verification", label: t("admin.field5Label"), placeholder: "false", description: t("admin.field5Desc") },
                { key: "max_login_attempts", label: t("admin.field6Label"), type: "number", placeholder: "10", description: t("admin.field6Desc") },
            ]}
        />
    );
}
