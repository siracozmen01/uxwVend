"use client";

import { useTranslations } from "next-intl";
import { AdminCrudPage } from "@/core/components/admin/AdminCrudPage";

export default function Page() {
    const t = useTranslations("servers");
    return (
        <AdminCrudPage
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            apiPath="/api/v1/servers"
            listKey="servers"
            displayField="name"
            secondaryField="host"
            fields={[
                { key: "name", label: t("admin.field1Label"), required: true, placeholder: t("admin.field1Placeholder") },
                { key: "type", label: t("admin.field2Label"), type: "select", required: true, options: [
                    { value: "minecraft", label: t("admin.field3Label") },
                    { value: "fivem", label: t("admin.field4Label") },
                    { value: "rust", label: t("admin.field5Label") },
                    { value: "ark", label: t("admin.field6Label") },
                    { value: "csgo", label: t("admin.field7Label") },
                ], defaultValue: "minecraft" },
                { key: "host", label: t("admin.field8Label"), required: true, placeholder: t("admin.field2Placeholder") },
                { key: "port", label: t("admin.field9Label"), type: "number", defaultValue: "25565" },
                { key: "queryPort", label: t("admin.field10Label"), type: "number", placeholder: t("admin.field3Placeholder") },
                { key: "rconPort", label: t("admin.field11Label"), type: "number", placeholder: t("admin.field4Placeholder") },
                { key: "rconPassword", label: t("admin.field12Label"), type: "text", placeholder: t("admin.field5Placeholder") },
                { key: "isDefault", label: t("admin.field13Label"), type: "toggle", defaultValue: "false" },
                { key: "isActive", label: t("admin.field14Label"), type: "toggle", defaultValue: "true" },
            ]}
        />
    );
}
