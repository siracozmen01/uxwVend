"use client";

import { useTranslations } from "next-intl";
import { SettingsForm } from "./settings-form";

export default function RconSettingsPage() {
    const t = useTranslations("servers");
    return (
        <SettingsForm
            title={t("admin.title")}
            subtitle={t("admin.subtitle")}
            fields={[
                { key: "rcon_host", label: t("admin.field1Label"), placeholder: "127.0.0.1", description: t("admin.field1Desc") },
                { key: "rcon_port", label: t("admin.field2Label"), type: "number", placeholder: "25575", description: t("admin.field2Desc") },
                { key: "rcon_password", label: t("admin.field3Label"), type: "password", placeholder: "your-rcon-password", description: t("admin.field3Desc") },
                { key: "mc_server_host", label: t("admin.field4Label"), placeholder: "play.example.com", description: t("admin.field4Desc") },
                { key: "mc_server_port", label: t("admin.field5Label"), type: "number", placeholder: "25565", description: t("admin.field5Desc") },
            ]}
        />
    );
}
