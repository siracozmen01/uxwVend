import { prisma } from "@/core/lib/db";

interface SearchResult {
    type: string;
    title: string;
    excerpt?: string;
    href: string;
}

/**
 * Federated search contribution for forum topics.
 * Called from /api/v1/search?q=... via the ModuleSearchProviders registry.
 */
export default async function search(q: string): Promise<SearchResult[]> {
    if (!q || q.length < 2) return [];
    const rows = await prisma.forumTopic.findMany({
        where: {
            OR: [
                { title: { contains: q, mode: "insensitive" } },
                { content: { contains: q, mode: "insensitive" } },
            ],
        },
        select: { title: true, slug: true, content: true },
        orderBy: { createdAt: "desc" },
        take: 5,
    });
    return rows.map((r) => ({
        type: "forum-topic",
        title: r.title,
        excerpt: r.content.slice(0, 140),
        href: `/forum/topic/${r.slug}`,
    }));
}
