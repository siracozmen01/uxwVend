import { NextResponse } from "next/server";
import { prisma } from "@/core/lib/db";

export async function GET() {
    const topics = await prisma.forumTopic.count();
    const recentTopics = await prisma.forumTopic.findMany({
        take: 5, orderBy: { createdAt: "desc" },
        include: { author: { select: { username: true } }, category: { select: { name: true } } },
    });

    return NextResponse.json({
        stats: { topics },
        sections: [{
            id: "recent-topics",
            title: "Latest Forum Topics",
            titleKey: "dashboard_latestForumTopics",
            viewAllHref: "/admin/forum/topics",
            items: recentTopics.map(t => ({
                id: t.id,
                primary: t.title,
                secondary: t.author.username + " · " + t.category.name,
            }))
        }]
    });
}
